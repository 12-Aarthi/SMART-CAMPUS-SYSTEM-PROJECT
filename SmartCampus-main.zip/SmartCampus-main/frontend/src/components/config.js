export const config = {
  MAP_API_KEY: "test",
};
