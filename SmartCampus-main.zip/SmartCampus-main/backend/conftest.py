def pytest_addoption(parser):
    parser.addoption(
        "--constring",
        action="store"
    )
