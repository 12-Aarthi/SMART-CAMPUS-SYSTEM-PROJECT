#define MICROPROFILE_META_MAX 16
#define MICROPROFILE_IMPL
#define MICROPROFILEUI_IMPL
#define MICROPROFILEDRAW_IMPL
#include "microprofile.h"
#include "microprofileui.h"

#include <glad/glad.h>
#include "microprofiledraw.h"
