#define MICROPROFILE_META_MAX 16
#define MICROPROFILE_IMPL
#include "microprofile.h"
