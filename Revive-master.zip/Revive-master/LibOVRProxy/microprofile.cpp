#define MICROPROFILE_IMPL
#define _CRT_SECURE_NO_WARNINGS
#include "microprofile.h"
